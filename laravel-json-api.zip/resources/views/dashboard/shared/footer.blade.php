<footer class="c-footer">
  <div> &copy; 2020 XiapiSync.</div>
  <div class="ml-auto">Powered by&nbsp;<a href="#">XiapiSync</a></div>
</footer>