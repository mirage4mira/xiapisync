/* eslint-disable object-shorthand */
/* global Chart, coreui, coreui.Utils.getStyle, coreui.Utils.hexToRgba */

/**
 * --------------------------------------------------------------------------
 * CoreUI Boostrap Admin Template (v3.0.0): main.js
 * Licensed under MIT (https://coreui.io/license)
 * --------------------------------------------------------------------------
 */

/* eslint-disable no-magic-numbers */
// Disable the on-canvas tooltip

//date format
var AJAX_DATE_FORMAT = "yyyy-M-d";

//chart configs
if(typeof Chart !== 'undefined'){
  Chart.defaults.global.pointHitDetectionRadius = 1
  Chart.defaults.global.tooltips.enabled = false
  Chart.defaults.global.tooltips.mode = 'index'
  Chart.defaults.global.tooltips.position = 'nearest'
  Chart.defaults.global.tooltips.custom = coreui.ChartJS.customTooltips
  Chart.defaults.global.defaultFontColor = '#646470'
  Chart.defaults.global.responsiveAnimationDuration = 1
}

document.body.addEventListener('classtoggle', event => {
  if (event.detail.className === 'c-dark-theme') {
    if (document.body.classList.contains('c-dark-theme')) {
      cardChart1.data.datasets[0].pointBackgroundColor = coreui.Utils.getStyle('--primary-dark-theme')
      cardChart2.data.datasets[0].pointBackgroundColor = coreui.Utils.getStyle('--info-dark-theme')
      Chart.defaults.global.defaultFontColor = '#fff'
    } else {
      cardChart1.data.datasets[0].pointBackgroundColor = coreui.Utils.getStyle('--primary')
      cardChart2.data.datasets[0].pointBackgroundColor = coreui.Utils.getStyle('--info')
      Chart.defaults.global.defaultFontColor = '#646470'
    }

    cardChart1.update()
    cardChart2.update()
    mainChart.update()
  }
})

//handleErrors
var ajaxErrorResponse = function(jqXhr, json, errorThrown){// this are default for ajax errors 
  var errors = jqXhr.responseJSON;
  var errorsHtml = '';
  $.each(errors['errors'], function (index, value) {
      errorsHtml += '<ul class="list-group"><li class="list-group-item alert alert-danger">' + value + '</li></ul>';
  });
  var myhtml = document.createElement("div");
  myhtml.innerHTML = errorsHtml;
  //I use SweetAlert2 for this
  swal({
      title: "Error " + jqXhr.status + ': ' + errorThrown,// this will output "Error 422: Unprocessable Entity"
      content: myhtml,
      width: 'auto',
      confirmButtonText: 'Try again',
      cancelButtonText: 'Cancel',
      confirmButtonClass: 'btn',
      cancelButtonClass: 'cancel-class',
      showCancelButton: true,
      closeOnConfirm: true,
      closeOnCancel: true,
      type: 'error'
    }).then(function(isConfirm) {
    if (isConfirm) {
         $('#openModal').click();//this is when the form is in a modal
    }
});
};

function getProductsData(){
  return $.ajax({
      async: true,
      type: 'POST',
      url: '/get-products-detail',
      data: {_token: CSRF_TOKEN},
      success: function(data) {
        console.log(data);
      },
      error: ajaxErrorResponse
  });
}

function getOrdersEscrowData(status,start_date,end_date){
  return $.ajax({
    async: true,
    type: 'POST',
    url: '/get-orders-esrow-detail',
    data: {_token: CSRF_TOKEN,status,start_date,end_date},
    success: function(data) {
      console.log(data);
    },
    error: ajaxErrorResponse
  });
}

function initDoubleDatepicker(selector1,selector2){

  var date1 = $(selector1);
  var date2 = $(selector2);

  date1.datepicker().on('changeDate',function(){
    $(this).datepicker('hide');
  })
  date2.datepicker({
    orientation: "auto right"
  }).on('changeDate',function(){
    $(this).datepicker('hide');
  }) 

  date1.datepicker().on('hide',function(selectedDate){
    var date = $(this).datepicker("getDate");
            date2.datepicker("setDate", date);
            date2.datepicker( "show" );
  });

  date2.datepicker().on('hide',function(selectedDate){
    var date = $(this).datepicker({ dateFormat: 'mm/dd/yy' }).val();
    date1.val(date1.val() + " - " + date);
    date1.change();
  });
}

function money(money){
  return (money).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
}

// eslint-disable-next-line no-unused-vars
// eslint-disable-next-line no-unused-vars

