<footer class="c-footer">
  <div> &copy; 2020 XiapiSync.</div>
  <div class="ml-auto">Powered by&nbsp;<a href="#">XiapiSync</a></div>
</footer><?php /**PATH C:\Users\David Ngu\my project\resources\views/dashboard/shared/footer.blade.php ENDPATH**/ ?>