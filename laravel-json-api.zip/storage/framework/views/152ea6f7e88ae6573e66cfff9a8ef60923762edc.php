

<?php $__env->startSection('content'); ?>

    <div class="container">
      <div class="row justify-content-center">
        <div class="col-md-8">
          <div class="card">
            <div class="card-body">
                <h2 class="card-title">
                    Sign in Shop
                </h2>
                <p class="card-subtitle mb-2 text-muted">Sign in to a shop to proceed. You can add more shops later.</p>
                <div class="row" style="margin-top:30px">
                    <div class="col-md-6 border-right text-center">
                        <img src="/images/shopee-logo.png" height="70px">
                        <div style="margin:20px 0px">
                            <a href="<?php echo e($shopeeAuthLink); ?>"><button class="btn btn-primary">Sign in Shopee</button></a>
                        </div>
                    </div>
                    <div class="col-md-6 text-center">
                        <img src="/images/lazada-logo.png" height="70px">
                        <div style="margin:20px 0px">
                            <button class="btn btn-light" disabled style="cursor:context-menu">Coming Soon</button>
                        </div>
                    </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.authBase', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\David Ngu\my project\resources\views/sign-in-platform.blade.php ENDPATH**/ ?>